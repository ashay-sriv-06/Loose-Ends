# Disclosures

## What is in this package

Only Markdown: `SKILL.md` and the files under `references/`. It contains no third-party code, scripts, executables, manifests, binaries, credentials, personal data, or sample client files.

## Third-party components

**Skill package:** none.

**Local companion prototype** (separate from this package, used for development and demonstration on a laptop; not submitted in this ZIP and not runnable inside a Skill):

| Component | Source | License | Use |
|---|---|---|---|
| React, React DOM | https://react.dev | MIT | Companion user interface |
| Vite, @vitejs/plugin-react | https://vite.dev | MIT | Development server and build |
| TypeScript | https://www.typescriptlang.org | Apache-2.0 | Language and type checking |
| tsx | https://github.com/privatenumber/tsx | MIT | Running TypeScript on Node.js |
| Vitest | https://vitest.dev | MIT | Tests |
| concurrently | https://github.com/open-cli-tools/concurrently | MIT | Running two development processes |
| playwright-core | https://playwright.dev | Apache-2.0 | Browser walk-through test of the companion (development only) |
| Node.js | https://nodejs.org | MIT | Local runtime |
| ReportLab | https://www.reportlab.com/opensource | BSD | Generating the proposal PDF |

## External services and data flows

None. The Skill uses only files the user names on the NAS and sends nothing outside it. The companion prototype runs on loopback with synthetic demo files; it calls no AI model and no external service (commitments are read from the brief by fixed rules that the user can correct).

## Newly developed for this hackathon

- This Skill: the Choose - Check - Fix workflow, the delivery-boundary ("What your client gets") check, approval-to-version matching rules, source-authority rules, and the output contract.
- The local companion prototype and its synthetic "Acme Brand Launch" demo files.

Nothing here reuses a previously developed Skill or earlier submission material.

## AI tools used

Claude Code (Anthropic) was used to draft and edit this Skill's text, write the companion prototype's code and tests, and prepare the proposal document, under the entrant's direction and review.

## Development status

- This is an initial package written against the publicly documented format and capability areas in the Hackathon Starter Kit and Official Rules.
- It has not been run on a UGREEN NAS.
- The local companion prototype works end to end on synthetic files on a laptop (automated tests and a browser walk-through). That is a local demonstration only, not evidence of NAS behaviour.
- The capability areas named in SKILL.md (Files: find, browse; Documents: read, extract, reconcile) are those listed publicly; binding each step to the exact command names in the official creation tool, and passing that tool's check, is the next step.
- Whether NAS capabilities return image dimensions or content fingerprints is not yet known; the Skill reports `unable-to-inspect` where they do not.
